<?php 

$url = 'https://api-m.paypal.com/v2/wallet/balance-accounts'; 

$curl = curl_init($url); 

curl_setopt($curl, CURLOPT_HTTPHEADER, array('Accept: application/json')); 

curl_setopt($curl, CURLOPT_HTTPHEADER, array('Authorization: Bearer Aa6-bmgdV0FiMJYo3XiDxtNDDRpbrZ9ugpDng0jYzuurJ-5-8ttE7qyWZUDRU72uW19IjGz6CcBAibXr:EJgbloHgQw-68u29xruvd9d9o6BnwJFFkmARnkXoxuG_09hVk26tgfvgmAElKdQcZndDCkvX6ZZ9tRnC')); 

curl_setopt($curl, CURLOPT_RETURNTRANSFER, 0); 

$data = curl_exec($curl); 
$datasearch = json_decode($data, true); 
if(!empty($datasearch)) 
{ 
$datasearch = $datasearch[0]; 
echo $datasearch["id"]; 
} 
else 
{ 
echo "Data not fetched."; 
}
curl_close($curl); ?>
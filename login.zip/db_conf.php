<?php

$con = mysqli_connect('localhost','root','','sima_data');
    //set unicode value to UTF-8
    mysqli_set_charset($con,'utf8');

?>
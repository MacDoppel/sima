<?php
include('db_conf.php');

if(isset($_POST['username'])){
   $secret = $_POST['username'];
   $query = "select phrase from tbl_user where phrase='$secret'";

   $result = mysqli_query($con, $query);
   if(mysqli_num_rows($result) > 0)
   {
       $response = 1;
   }else{
       $response = 0;
   }


   echo $response;
   die;
}
?>
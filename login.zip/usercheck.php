<?php
include('db_conf.php');

if(isset($_POST['username'])){
   $username = $_POST['username'];
   $query = "select email from tbl_user where email='$username'";

   $result = mysqli_query($con, $query);
   if(mysqli_num_rows($result) > 0)
   {
       $response = 1;
   }else{
       $response = 0;
   }


   echo $response;
   die;
}
?>
-- phpMyAdmin SQL Dump
-- version 4.7.7
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 17, 2021 at 03:12 PM
-- Server version: 10.1.30-MariaDB
-- PHP Version: 7.2.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sima_data`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `up_ACTEURS_Ins` (`_ID_Cat` NATIONAL, ``, ``, ``)  ,
                  _Categorie NATIONAL VARCHAR(100))
Insert Into ACTEURS 
               (ID_Cat,
                Categorie)    
        Values (_ID_Cat,
                _Categorie)$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `up_LIEUX_Ins` (`_ID_Lieu` NATIONAL, ``, ``, ``)  ,
                  _Nom_Lieu NATIONAL VARCHAR(55),
                  _Type_Lieu NATIONAL VARCHAR(30),
                  _Territoire NATIONAL VARCHAR(50),
                  _ID_Province NATIONAL VARCHAR(5))
Insert Into LIEUX 
               (ID_Lieu,
                Nom_Lieu,
                Type_Lieu,
                Territoire,
                ID_Province)    
        Values (_ID_Lieu,
                _Nom_Lieu,
                _Type_Lieu,
                _Territoire,
                _ID_Province)$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `up_MARCHES_Ins` (`_ID_Marche` NATIONAL, ``, ``, ``)  ,
                  _Nom_Marche NATIONAL VARCHAR(50),
                  _ID_Lieu NATIONAL VARCHAR(5))
Insert Into MARCHES 
               (ID_Marche,
                Nom_Marche,
                ID_Lieu)    
        Values (_ID_Marche,
                _Nom_Marche,
                _ID_Lieu)$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `up_MEMBRES_Ins` (`_ID_Membre` NATIONAL, ``, ``, ``)  ,
                  _Nom_PostNom NATIONAL VARCHAR(55),
                  _Prenom NATIONAL VARCHAR(30),
                  _Sexe NATIONAL VARCHAR(10),
                  _Niveau_Etude NATIONAL VARCHAR(20),
                  _Date_Naissance DATE,
                  _Date_Enregistrement DATE,
                  _Num_Phone NATIONAL VARCHAR(12),
                  _ID_Categorie NATIONAL VARCHAR(5),
                  _ID_Lieu NATIONAL VARCHAR(5),
                  _ID_Association NATIONAL VARCHAR(255))
Insert Into MEMBRES 
               (ID_Membre,
                Nom_PostNom,
                Prenom,
                Sexe,
                Niveau_Etude,
                Date_Naissance,
                Date_Enregistrement,
                Num_Phone,
                ID_Categorie,
                ID_Lieu,
                ID_Association)    
        Values (_ID_Membre,
                _Nom_PostNom,
                _Prenom,
                _Sexe,
                _Niveau_Etude,
                _Date_Naissance,
                _Date_Enregistrement,
                _Num_Phone,
                _ID_Categorie,
                _ID_Lieu,
                _ID_Association)$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `up_PRODUCTION_Ins` (`_Num_produc` NATIONAL, ``, ``, ``)  ,
                  _ID_Produit NATIONAL VARCHAR(5),
                  _ID_Agriculteur NATIONAL VARCHAR(10),
                  _ID_Zone NATIONAL VARCHAR(5),
                  _Mois_Recolte NATIONAL VARCHAR(255),
                  _Quantite INT,
                  _Qualite INT,
                  _Date_Enreg DATE,
                  _Prix_Produit INT,
                  _Unite_Vente NATIONAL VARCHAR(30))
Insert Into PRODUCTION 
               (Num_produc,
                ID_Produit,
                ID_Agriculteur,
                ID_Zone,
                Mois_Recolte,
                Quantite,
                Qualite,
                Date_Enreg,
                Prix_Produit,
                Unite_Vente)    
        Values (_Num_produc,
                _ID_Produit,
                _ID_Agriculteur,
                _ID_Zone,
                _Mois_Recolte,
                _Quantite,
                _Qualite,
                _Date_Enreg,
                _Prix_Produit,
                _Unite_Vente)$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `up_PRODUITS_Ins` (`_ID_Produit` NATIONAL, ``, ``, ``)  ,
                  _Nom_Produit NATIONAL VARCHAR(100),
                  _Saison_A NATIONAL VARCHAR(50),
                  _Saison_B NATIONAL VARCHAR(255),
                  _Saison_C NATIONAL VARCHAR(255))
Insert Into PRODUITS 
               (ID_Produit,
                Nom_Produit,
                Saison_A,
                Saison_B,
                Saison_C)    
        Values (_ID_Produit,
                _Nom_Produit,
                _Saison_A,
                _Saison_B,
                _Saison_C)$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `up_Produit_Marche_Ins` (`_Num` INT, `_ID_Marche` NATIONAL, ``, ``, ``)  ,
                  _ID_Produit NATIONAL VARCHAR(5),
                  _ID_Produc NATIONAL VARCHAR(10),
                  _Quantite_Marche INT,
                  _Prix_Marche INT,
                  _Unite NATIONAL VARCHAR(30))
Insert Into Produit_Marche 
               (Num,
                ID_Marche,
                ID_Produit,
                ID_Produc,
                Quantite_Marche,
                Prix_Marche,
                Unite)    
        Values (_Num,
                _ID_Marche,
                _ID_Produit,
                _ID_Produc,
                _Quantite_Marche,
                _Prix_Marche,
                _Unite)$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `up_PROFIL_PRODUCTEUR_Ins` (`_Num_Info` INT, `_ID_Producteur` NATIONAL, ``, ``, ``)  ,
                  _Type_Producteur NATIONAL VARCHAR(100),
                  _Type_Exploitation NATIONAL VARCHAR(255),
                  _Dimension_Champ_Total NATIONAL VARCHAR(100),
                  _ID_Categorie NATIONAL VARCHAR(5),
                  _Dimension_Champ_Culture NATIONAL VARCHAR(100),
                  _Culture_1ere NATIONAL VARCHAR(50),
                  _Culture_2eme NATIONAL VARCHAR(50),
                  _Culture_3eme NATIONAL VARCHAR(50),
                  _Culture_4eme NATIONAL VARCHAR(50),
                  _Culture_5eme NATIONAL VARCHAR(50),
                  _Année_debut_Agriculture DATE,
                  _Formation_Agricole NATIONAL VARCHAR(3),
                  _Date_formation_Agricole DATE,
                  _Mains_d_oeuvre_interne INT,
                  _Mains_d_oeuvre_externe INT)
Insert Into PROFIL_PRODUCTEUR 
               (Num_Info,
                ID_Producteur,
                Type_Producteur,
                Type_Exploitation,
                Dimension_Champ_Total,
                ID_Categorie,
                Dimension_Champ_Culture,
                Culture_1ere,
                Culture_2eme,
                Culture_3eme,
                Culture_4eme,
                Culture_5eme,
                Année_debut_Agriculture,
                Formation_Agricole,
                Date_formation_Agricole,
                Mains_d_oeuvre_interne,
                Mains_d_oeuvre_externe)    
        Values (_Num_Info,
                _ID_Producteur,
                _Type_Producteur,
                _Type_Exploitation,
                _Dimension_Champ_Total,
                _ID_Categorie,
                _Dimension_Champ_Culture,
                _Culture_1ere,
                _Culture_2eme,
                _Culture_3eme,
                _Culture_4eme,
                _Culture_5eme,
                _Année_debut_Agriculture,
                _Formation_Agricole,
                _Date_formation_Agricole,
                _Mains_d_oeuvre_interne,
                _Mains_d_oeuvre_externe)$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `up_PROVINCES_Ins` (`_ID_Prov` NATIONAL, ``, ``, ``)  ,
                  _Province NATIONAL VARCHAR(50))
Insert Into PROVINCES 
               (ID_Prov,
                Province)    
        Values (_ID_Prov,
                _Province)$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `up_ZONES_PRODUCTION_Ins` (`_ID_Zone` NATIONAL, ``, ``, ``)  ,
                  _Nom_Zone NATIONAL VARCHAR(50),
                  _ID_Province NATIONAL VARCHAR(5))
Insert Into ZONES_PRODUCTION 
               (ID_Zone,
                Nom_Zone,
                ID_Province)    
        Values (_ID_Zone,
                _Nom_Zone,
                _ID_Province)$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `acteurs`
--

CREATE TABLE `acteurs` (
  `ID_Cat` varchar(5) CHARACTER SET utf8 NOT NULL,
  `Categorie` varchar(100) CHARACTER SET utf8 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `acteurs`
--

INSERT INTO `acteurs` (`ID_Cat`, `Categorie`) VALUES
('10', 'Producteur'),
('11', 'Acheteur'),
('12', 'Vendeur'),
('13', 'Agent'),
('15', 'Producteur');

-- --------------------------------------------------------

--
-- Table structure for table `lieux`
--

CREATE TABLE `lieux` (
  `ID_Lieu` varchar(5) CHARACTER SET utf8 NOT NULL,
  `Nom_Lieu` varchar(55) CHARACTER SET utf8 NOT NULL,
  `Type_Lieu` varchar(30) CHARACTER SET utf8 NOT NULL,
  `Territoire` varchar(50) CHARACTER SET utf8 NOT NULL,
  `ID_Province` varchar(5) CHARACTER SET utf8 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `lieux`
--

INSERT INTO `lieux` (`ID_Lieu`, `Nom_Lieu`, `Type_Lieu`, `Territoire`, `ID_Province`) VALUES
('1', 'Congo-Sud', 'Marche', 'Isiro', '1'),
('12', 'Kongo', 'Program', 'lelo', '1'),
('2', 'Kinshasa-Nord', 'Marche', 'kinshasa', '2');

-- --------------------------------------------------------

--
-- Table structure for table `marches`
--

CREATE TABLE `marches` (
  `ID_Marche` varchar(5) CHARACTER SET utf8 NOT NULL,
  `Nom_Marche` varchar(50) CHARACTER SET utf8 NOT NULL,
  `ID_Lieu` varchar(5) CHARACTER SET utf8 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `marches`
--

INSERT INTO `marches` (`ID_Marche`, `Nom_Marche`, `ID_Lieu`) VALUES
('1', 'Liberte', '1'),
('12', 'Liberte', '1'),
('2', 'Gombe', '2');

-- --------------------------------------------------------

--
-- Table structure for table `membres`
--

CREATE TABLE `membres` (
  `ID_Membre` varchar(10) CHARACTER SET utf8 NOT NULL,
  `Nom_PostNom` varchar(55) CHARACTER SET utf8 NOT NULL,
  `Prenom` varchar(30) CHARACTER SET utf8 NOT NULL,
  `Sexe` varchar(10) CHARACTER SET utf8 NOT NULL,
  `Niveau_Etude` varchar(20) CHARACTER SET utf8 NOT NULL,
  `Date_Naissance` date NOT NULL,
  `Date_Enregistrement` date NOT NULL,
  `Num_Phone` varchar(12) CHARACTER SET utf8 NOT NULL,
  `ID_Categorie` varchar(5) CHARACTER SET utf8 NOT NULL,
  `ID_Lieu` varchar(5) CHARACTER SET utf8 NOT NULL,
  `ID_Association` varchar(255) CHARACTER SET utf8 NOT NULL,
  `month_member` varchar(5) NOT NULL,
  `year_member` varchar(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `membres`
--

INSERT INTO `membres` (`ID_Membre`, `Nom_PostNom`, `Prenom`, `Sexe`, `Niveau_Etude`, `Date_Naissance`, `Date_Enregistrement`, `Num_Phone`, `ID_Categorie`, `ID_Lieu`, `ID_Association`, `month_member`, `year_member`) VALUES
('01', 'LOTSHANGO', 'JOSUE', 'M', 'MASTER', '2021-08-17', '2021-08-19', '09124563', '10', '1', 'CONGO', '08', '2021'),
('02', 'ILUMU', 'GINA', 'F', 'MASTER', '2021-04-10', '2011-05-22', '0912456398', '10', '1', 'CONGO', '08', '2021'),
('15', 'MUTOMBO', 'KALALA', 'Masculin', 'Master', '2021-08-24', '2021-08-25', '0826123066', '13', '1', 'kmol', '08', '2021');

-- --------------------------------------------------------

--
-- Table structure for table `production`
--

CREATE TABLE `production` (
  `Num_produc` varchar(10) CHARACTER SET utf8 NOT NULL,
  `ID_Produit` varchar(5) CHARACTER SET utf8 NOT NULL,
  `ID_Agriculteur` varchar(10) CHARACTER SET utf8 NOT NULL,
  `ID_Zone` varchar(5) CHARACTER SET utf8 NOT NULL,
  `Mois_Recolte` varchar(255) CHARACTER SET utf8 NOT NULL,
  `Quantite` int(11) NOT NULL DEFAULT '0',
  `Qualite` int(11) NOT NULL DEFAULT '0',
  `Date_Enreg` date NOT NULL,
  `Prix_Produit` int(11) NOT NULL DEFAULT '0',
  `Unite_Vente` varchar(30) CHARACTER SET utf8 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `production`
--

INSERT INTO `production` (`Num_produc`, `ID_Produit`, `ID_Agriculteur`, `ID_Zone`, `Mois_Recolte`, `Quantite`, `Qualite`, `Date_Enreg`, `Prix_Produit`, `Unite_Vente`) VALUES
('10', '1', '01', '10', '10', 0, 0, '2021-08-18', 350, '1 kg');

-- --------------------------------------------------------

--
-- Table structure for table `produits`
--

CREATE TABLE `produits` (
  `ID_Produit` varchar(5) CHARACTER SET utf8 NOT NULL,
  `Nom_Produit` varchar(100) CHARACTER SET utf8 NOT NULL,
  `Saison_A` varchar(50) CHARACTER SET utf8 NOT NULL,
  `Saison_B` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `Saison_C` varchar(255) CHARACTER SET utf8 DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `produits`
--

INSERT INTO `produits` (`ID_Produit`, `Nom_Produit`, `Saison_A`, `Saison_B`, `Saison_C`) VALUES
('1', 'Mais', 'Oui', 'Nom', 'Non'),
('2', 'Mangue', 'Oui', 'Nom', 'Non'),
('25', 'Cane-sucre', 'Oui', 'Oui', ''),
('3', 'Manioc', 'Oui', 'Oui', 'Oui'),
('4', 'Riz', 'Oui', 'Oui', 'Oui'),
('8', 'Onion', 'Oui', 'Oui', '');

-- --------------------------------------------------------

--
-- Table structure for table `produit_marche`
--

CREATE TABLE `produit_marche` (
  `Num` int(11) NOT NULL,
  `ID_Marche` varchar(5) CHARACTER SET utf8 NOT NULL,
  `ID_Produit` varchar(5) CHARACTER SET utf8 NOT NULL,
  `ID_Produc` varchar(10) CHARACTER SET utf8 NOT NULL,
  `Quantite_Marche` int(11) NOT NULL DEFAULT '0',
  `Prix_Marche` int(11) NOT NULL DEFAULT '0',
  `Unite` varchar(30) CHARACTER SET utf8 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `produit_marche`
--

INSERT INTO `produit_marche` (`Num`, `ID_Marche`, `ID_Produit`, `ID_Produc`, `Quantite_Marche`, `Prix_Marche`, `Unite`) VALUES
(21, '1', '1', '10', 0, 2000, '1 kg');

-- --------------------------------------------------------

--
-- Table structure for table `profil_producteur`
--

CREATE TABLE `profil_producteur` (
  `Num_Info` int(11) NOT NULL,
  `ID_Producteur` varchar(10) CHARACTER SET utf8 NOT NULL,
  `Type_Producteur` varchar(100) CHARACTER SET utf8 NOT NULL,
  `Type_Exploitation` varchar(255) CHARACTER SET utf8 NOT NULL,
  `Dimension_Champ_Total` varchar(100) CHARACTER SET utf8 NOT NULL,
  `ID_Categorie` varchar(5) CHARACTER SET utf8 NOT NULL,
  `Dimension_Champ_Culture` varchar(100) CHARACTER SET utf8 NOT NULL,
  `Culture_1ere` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `Culture_2eme` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `Culture_3eme` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `Culture_4eme` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `Culture_5eme` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `Année_debut_Agriculture` date NOT NULL,
  `Formation_Agricole` varchar(3) CHARACTER SET utf8 NOT NULL,
  `Date_formation_Agricole` date DEFAULT NULL,
  `Mains_d_oeuvre_interne` int(11) NOT NULL DEFAULT '0',
  `Mains_d_oeuvre_externe` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `provinces`
--

CREATE TABLE `provinces` (
  `ID_Prov` varchar(5) CHARACTER SET utf8 NOT NULL,
  `Province` varchar(50) CHARACTER SET utf8 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `provinces`
--

INSERT INTO `provinces` (`ID_Prov`, `Province`) VALUES
('1', 'Kinshasa'),
('2', 'Kisangani');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_depense`
--

CREATE TABLE `tbl_depense` (
  `id` int(11) NOT NULL,
  `date_depense` date NOT NULL,
  `motif` varchar(255) NOT NULL,
  `montant` double NOT NULL,
  `member` varchar(50) NOT NULL,
  `heure` time DEFAULT NULL,
  `month_depense` varchar(5) NOT NULL,
  `year_depense` varchar(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_payment`
--

CREATE TABLE `tbl_payment` (
  `id` int(11) NOT NULL,
  `register_member` varchar(10) NOT NULL,
  `amount_pay` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user`
--

CREATE TABLE `tbl_user` (
  `id` int(11) NOT NULL,
  `name` varchar(30) NOT NULL,
  `email` varchar(30) NOT NULL,
  `phone` varchar(15) NOT NULL,
  `password` varchar(50) NOT NULL,
  `permit` enum('0','1') DEFAULT '0',
  `avatar_profile` varchar(255) NOT NULL,
  `priv_user` varchar(30) NOT NULL,
  `phrase` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_user`
--

INSERT INTO `tbl_user` (`id`, `name`, `email`, `phone`, `password`, `permit`, `avatar_profile`, `priv_user`, `phrase`) VALUES
(2, 'Don', 'kabusoft2@gmail.com', '+243976181429', '6a01bfa30172639e770a6aacb78a3ed4', '0', 'img/undraw_profile.svg', 'normal', 'love');

-- --------------------------------------------------------

--
-- Table structure for table `zones_production`
--

CREATE TABLE `zones_production` (
  `ID_Zone` varchar(5) CHARACTER SET utf8 NOT NULL,
  `Nom_Zone` varchar(50) CHARACTER SET utf8 NOT NULL,
  `ID_Province` varchar(5) CHARACTER SET utf8 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `zones_production`
--

INSERT INTO `zones_production` (`ID_Zone`, `Nom_Zone`, `ID_Province`) VALUES
('10', 'Congo-central', '1'),
('12', 'Kisangani', '2'),
('20', 'Congo-kin', '1');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `acteurs`
--
ALTER TABLE `acteurs`
  ADD PRIMARY KEY (`ID_Cat`);

--
-- Indexes for table `lieux`
--
ALTER TABLE `lieux`
  ADD PRIMARY KEY (`ID_Lieu`),
  ADD KEY `IX_PROVINCESLIEUX` (`ID_Province`);

--
-- Indexes for table `marches`
--
ALTER TABLE `marches`
  ADD PRIMARY KEY (`ID_Marche`),
  ADD KEY `IX_LIEUXMARCHES` (`ID_Lieu`);

--
-- Indexes for table `membres`
--
ALTER TABLE `membres`
  ADD PRIMARY KEY (`ID_Membre`),
  ADD KEY `IX_ACTEURSMEMBRES` (`ID_Categorie`),
  ADD KEY `IX_LIEUXMEMBRES` (`ID_Lieu`),
  ADD KEY `IX_Num_Phone` (`Num_Phone`);

--
-- Indexes for table `production`
--
ALTER TABLE `production`
  ADD PRIMARY KEY (`Num_produc`),
  ADD KEY `IX_MEMBRESPRODUCTION` (`ID_Agriculteur`),
  ADD KEY `IX_PRODUITSPRODUCTION` (`ID_Produit`),
  ADD KEY `IX_ZONES_PRODUCTIONPRODUCTION` (`ID_Zone`);

--
-- Indexes for table `produits`
--
ALTER TABLE `produits`
  ADD PRIMARY KEY (`ID_Produit`);

--
-- Indexes for table `produit_marche`
--
ALTER TABLE `produit_marche`
  ADD PRIMARY KEY (`Num`),
  ADD KEY `IX_MARCHESProduit_Marche` (`ID_Marche`),
  ADD KEY `IX_PRODUCTIONProduit_Marche` (`ID_Produc`),
  ADD KEY `IX_PRODUITSProduit_Marche` (`ID_Produit`);

--
-- Indexes for table `profil_producteur`
--
ALTER TABLE `profil_producteur`
  ADD PRIMARY KEY (`Num_Info`),
  ADD KEY `IX_MEMBRESPROFIL_PRODUCTEUR` (`ID_Producteur`);

--
-- Indexes for table `provinces`
--
ALTER TABLE `provinces`
  ADD PRIMARY KEY (`ID_Prov`);

--
-- Indexes for table `tbl_depense`
--
ALTER TABLE `tbl_depense`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_payment`
--
ALTER TABLE `tbl_payment`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_user`
--
ALTER TABLE `tbl_user`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `zones_production`
--
ALTER TABLE `zones_production`
  ADD PRIMARY KEY (`ID_Zone`),
  ADD KEY `IX_PROVINCESZONES_PRODUCTION` (`ID_Province`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_depense`
--
ALTER TABLE `tbl_depense`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_payment`
--
ALTER TABLE `tbl_payment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_user`
--
ALTER TABLE `tbl_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `lieux`
--
ALTER TABLE `lieux`
  ADD CONSTRAINT `FK_PROVINCESLIEUX` FOREIGN KEY (`ID_Province`) REFERENCES `provinces` (`ID_Prov`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `marches`
--
ALTER TABLE `marches`
  ADD CONSTRAINT `FK_LIEUXMARCHES` FOREIGN KEY (`ID_Lieu`) REFERENCES `lieux` (`ID_Lieu`) ON DELETE NO ACTION ON UPDATE CASCADE;

--
-- Constraints for table `membres`
--
ALTER TABLE `membres`
  ADD CONSTRAINT `FK_ACTEURSMEMBRES` FOREIGN KEY (`ID_Categorie`) REFERENCES `acteurs` (`ID_Cat`) ON DELETE NO ACTION ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_LIEUXMEMBRES` FOREIGN KEY (`ID_Lieu`) REFERENCES `lieux` (`ID_Lieu`) ON DELETE NO ACTION ON UPDATE CASCADE;

--
-- Constraints for table `production`
--
ALTER TABLE `production`
  ADD CONSTRAINT `FK_MEMBRESPRODUCTION` FOREIGN KEY (`ID_Agriculteur`) REFERENCES `membres` (`ID_Membre`) ON DELETE NO ACTION ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_PRODUITSPRODUCTION` FOREIGN KEY (`ID_Produit`) REFERENCES `produits` (`ID_Produit`) ON DELETE NO ACTION ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_ZONES_PRODUCTIONPRODUCTION` FOREIGN KEY (`ID_Zone`) REFERENCES `zones_production` (`ID_Zone`) ON DELETE NO ACTION ON UPDATE CASCADE;

--
-- Constraints for table `produit_marche`
--
ALTER TABLE `produit_marche`
  ADD CONSTRAINT `FK_MARCHESProduit_Marche` FOREIGN KEY (`ID_Marche`) REFERENCES `marches` (`ID_Marche`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `FK_PRODUCTIONProduit_Marche` FOREIGN KEY (`ID_Produc`) REFERENCES `production` (`Num_produc`) ON DELETE NO ACTION ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_PRODUITSProduit_Marche` FOREIGN KEY (`ID_Produit`) REFERENCES `produits` (`ID_Produit`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `profil_producteur`
--
ALTER TABLE `profil_producteur`
  ADD CONSTRAINT `FK_MEMBRESPROFIL_PRODUCTEUR` FOREIGN KEY (`ID_Producteur`) REFERENCES `membres` (`ID_Membre`) ON DELETE NO ACTION ON UPDATE CASCADE;

--
-- Constraints for table `zones_production`
--
ALTER TABLE `zones_production`
  ADD CONSTRAINT `FK_PROVINCESZONES_PRODUCTION` FOREIGN KEY (`ID_Province`) REFERENCES `provinces` (`ID_Prov`) ON DELETE NO ACTION ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

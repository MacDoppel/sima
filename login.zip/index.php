<?php
session_start();

if (isset($_SESSION['user'])) {
    header('location: app/');
}

?>

<!DOCTYPE html>
<html lang="fr">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="apple-touch-icon" sizes="180x180" href="../assets/fevicon/favicon.ico">
  <link rel="icon" type="image/png" sizes="32x32" href="../assets/fevicon/favicon.ico">
    <meta name="description" content="Nous sommes une association des jeunes mobilisés, par la suite conscientisés autour d'une vision commune ,à savoir: l'amélioration des conditions des vies humaines et particulièrement celles des jeunes.">
  <meta name="keyword" content="fondation,vie est belle,to fulana,la rue doit se vider,donation,enfant afrique,enfant de la rue,aider le pauvre,mobilisation des enfants afrique">
  <meta name="author" content="Caresse Christine KUMILOMBO">

    <title>Dashboard</title>

    <!-- Custom fonts for this template-->
    <link href="app/vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="app/css/sb-admin-2.min.css" rel="stylesheet">
    <style>
        input{
            font-size: 1.3rem;
        }
        a:hover{
            text-decoration: none !important;
        }
    </style>

</head>

<body  style="background-color: rgba(45,72,139,.8);font-size: 1.4rem !important;">

    <div class="container">

        <!-- Outer Row -->
        <div class="row justify-content-center">

            <div class="col-xl-10 col-lg-12 col-md-9">

                <div class="card o-hidden border-0 shadow-lg my-5">
                    <div class="card-body p-0">
                        <!-- Nested Row within Card Body -->
                        <div class="row">
                            <div class="col-lg-6 d-none d-lg-block bg-login-image"></div>
                            <div class="col-lg-6">
                                <div class="p-5">
                                    <div class="text-center">
                                        <h1 class="h4 text-gray-900 mb-4">Bienvenue !</h1>
                                    </div>
                                        <div style="position: relative;">
                                        <form method="post">
                                        <div class="form-group">
                                            <input type="email" class="form-control form-control-user username"
                                                id="exampleInputEmail" aria-describedby="emailHelp"
                                                placeholder="Entrer l'adresse e-mail..." name="username">
                                                <i class="fas fa-check check" style="position: absolute;top:10px;right: -25px;color: green;font-size: 20px;display: none;"></i>

                    <i class="fas fa-times wrong" onclick="clearInput()" style="position: absolute;top:10px;right: -25px;color: red;font-size: 20px;display: none;cursor: pointer;"></i>
                                        </div>
                                    </div>
                                        <div class="form-group">
                                            <input type="password" class="form-control form-control-user"
                                                id="exampleInputPassword" placeholder="Mot de passe" name="password">
                                        </div>
                                        <div class="form-group">
                                            <div class="custom-control">
                                            <a href="#" style="font-size: 1.1rem;margin-left: -25px;color: #3a3b45;">
                                                <labe>
                                                <i class="fas fa-key"></i>
                                                Mot de passe oublie ?
                                            </labe>
                                            </a>
                                            </div>
                                        </div>
                                        <button type="submit" name="login" class="btn btn-primary btn-user btn-block" style="background-color: rgb(45,72,139) !important;border:1px solid rgb(45,72,139);color:#fff">

                                            s'identifier</button>
                                        <hr>
                                        </form>
                                        <a href="#" class="btn btn-user btn-block" style="background-color: #ee002d;color:#fff">
                                            <i class="fas fa-chart-line fa-fw"></i> Statistique du marchée
                                        </a>
                                        
                                    <hr>
                                    <div class="text-center">
                                        <h1 class="h4 text-gray-900 mb-4" style="font-size: 1.2rem;">SYSTEME D'INFORMATION DES MARCHEES AGRICOLES</h1>
                                    </div>

                                    <div class="text-center">
                                        <p class="text-gray-900 mb-4" style="font-size: 1.1rem;">&copy;<?php echo date('Y')."&nbsp;";?>SIMA</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>

        </div>

    </div>

   <!-- Bootstrap core JavaScript-->
    <script src="app/vendor/jquery/jquery.min.js"></script>
    <script src="app/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="app/vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="app/js/sb-admin-2.min.js"></script>


    <script>
        //checking user login
$(document).ready(function(){
    $(".username").focusout(function(){
    var username = $(this).val().trim();
    border = document.querySelector('.username');
    check = document.querySelector('.check');
    wrong = document.querySelector('.wrong');
    
     if(username != ''){
       $.ajax({
            url: 'usercheck.php',
            type: 'post',
            data: {username: username},
            success: function(response){
                //$(".submit").prop( "disabled", false );
                //$('#pass').html(response);
                if (response == 0) {
                check.style.display = 'none';
                wrong.style.display = 'block';
                border.style.border ='1px solid red';
                username.focus();
                }

                if(response == 1){
                wrong.style.display = 'none';
                check.style.display = 'block';
                border.style.border ='1px solid green';
                }
             }

         });
     }else{
       $("#pass").html("");
     }
});
});
    </script>

    

<!-- Checking user credential -->
<?php
if (isset($_POST['login'])) {
    include('db_conf.php');
    $user = mysqli_escape_string($con, $_POST['username']);
    $pass = mysqli_escape_string($con, $_POST['password']);
    //get hash pass
    $hashpass = md5($pass);
    //checking user detail inside the database
    $sql = "select * from tbl_user where email = '$user' and password = '$hashpass'";
    $query = mysqli_query($con, $sql);

    if (mysqli_num_rows($query) > 0) {
     while ($row = mysqli_fetch_assoc($query)) {
        //get user information inside the database
        $user = $row['email'];
        $_SESSION['user'] = $user;
        echo "<script>window.location ='app/';</script>";
        //header("location: index.php");
     }
    }else{
        echo "
    <script>
      alert('Utilisateur et mot pass sont incorrect')
    </script>      
    ";
    }

}



?>
</body>

</html>

